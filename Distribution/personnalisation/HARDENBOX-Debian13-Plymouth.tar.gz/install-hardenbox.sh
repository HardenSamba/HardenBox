#!/bin/bash
set -euo pipefail

THEME="hardenbox"
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="/usr/share/plymouth/themes/${THEME}"

if [[ $EUID -ne 0 ]]; then
  echo "Usage: sudo $0"
  exit 1
fi

apt-get update
apt-get install -y plymouth plymouth-themes plymouth-label initramfs-tools

mkdir -p "$DEST"
cp -a "$SRC/usr/share/plymouth/themes/hardenbox/." "$DEST/"

# Backup GRUB configuration.
cp -a /etc/default/grub "/etc/default/grub.hardenbox.backup.$(date +%Y%m%d-%H%M%S)"

# Ensure the splash parameter is enabled.
if grep -q '^GRUB_CMDLINE_LINUX_DEFAULT=' /etc/default/grub; then
  sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"/' /etc/default/grub
else
  echo 'GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"' >> /etc/default/grub
fi

update-grub
plymouth-set-default-theme -R hardenbox
update-initramfs -u -k all

echo
echo "HARDENBOX Plymouth installé."
echo "Redémarrage conseillé : systemctl reboot"
