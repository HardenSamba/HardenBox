HARDENBOX — Debian 13 Plymouth Theme
======================================

Installation:
  sudo ./install-hardenbox.sh

Le script :
  - installe les composants Plymouth nécessaires
  - installe le thème dans /usr/share/plymouth/themes/hardenbox/
  - active "quiet splash" dans GRUB
  - sélectionne HARDENBOX
  - reconstruit tous les initramfs

Fichiers du thème:
  hardenbox.plymouth
  hardenbox.script
  hardenbox-icon.png
  hardenbox-wordmark.png
  progress-bg.png
  progress-fg.png

Wallpaper:
  HARDENBOX-Debian13-Wallpaper-3840x2160.png (16:9)

Activation manuelle:
  sudo plymouth-set-default-theme -R hardenbox
  sudo update-initramfs -u -k all

Retour au thème précédent:
  sudo plymouth-set-default-theme -r
  sudo update-initramfs -u -k all

Remarque:
  Le thème utilise le plugin Plymouth "script", fourni par Debian.
