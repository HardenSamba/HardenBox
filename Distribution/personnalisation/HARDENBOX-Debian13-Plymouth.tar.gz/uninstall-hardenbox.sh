#!/bin/bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
  echo "Usage: sudo $0"
  exit 1
fi
plymouth-set-default-theme -r || true
update-initramfs -u -k all
rm -rf /usr/share/plymouth/themes/hardenbox
echo "HARDENBOX Plymouth removed. GRUB was not modified by this script."
